/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_144()
{
    return 2713436760U;
}

unsigned getval_360()
{
    return 1053003848U;
}

unsigned getval_315()
{
    return 3347646553U;
}

unsigned getval_254()
{
    return 3284633928U;
}

unsigned addval_376(unsigned x)
{
    return x + 2428995912U;
}

unsigned getval_423()
{
    return 2421707898U;
}

unsigned addval_230(unsigned x)
{
    return x + 3347794001U;
}

unsigned addval_499(unsigned x)
{
    return x + 12816472U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_325(unsigned x)
{
    return x + 3536115337U;
}

unsigned getval_333()
{
    return 3281109385U;
}

void setval_400(unsigned *p)
{
    *p = 3281049225U;
}

void setval_425(unsigned *p)
{
    *p = 3286272072U;
}

unsigned addval_245(unsigned x)
{
    return x + 3524837769U;
}

unsigned getval_390()
{
    return 3224947337U;
}

unsigned addval_489(unsigned x)
{
    return x + 3247494793U;
}

unsigned getval_161()
{
    return 3527988873U;
}

void setval_186(unsigned *p)
{
    *p = 2428602665U;
}

void setval_241(unsigned *p)
{
    *p = 3281049217U;
}

unsigned addval_324(unsigned x)
{
    return x + 3281046185U;
}

unsigned getval_471()
{
    return 3286272328U;
}

void setval_322(unsigned *p)
{
    *p = 3372799625U;
}

void setval_486(unsigned *p)
{
    *p = 3224950401U;
}

unsigned getval_474()
{
    return 3232022921U;
}

unsigned getval_167()
{
    return 2425670281U;
}

unsigned getval_141()
{
    return 3252717896U;
}

unsigned addval_304(unsigned x)
{
    return x + 2430634314U;
}

void setval_229(unsigned *p)
{
    *p = 2425405849U;
}

unsigned addval_473(unsigned x)
{
    return x + 3250686314U;
}

unsigned getval_364()
{
    return 2425408169U;
}

unsigned addval_337(unsigned x)
{
    return x + 3531917960U;
}

unsigned getval_301()
{
    return 3251276202U;
}

unsigned addval_200(unsigned x)
{
    return x + 3767355455U;
}

void setval_374(unsigned *p)
{
    *p = 3268053366U;
}

unsigned addval_385(unsigned x)
{
    return x + 3224947337U;
}

void setval_242(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_171(unsigned x)
{
    return x + 3525362057U;
}

void setval_363(unsigned *p)
{
    *p = 3286272360U;
}

void setval_416(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_249()
{
    return 3223372161U;
}

unsigned addval_283(unsigned x)
{
    return x + 3600373734U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
